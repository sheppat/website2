import tkinter as tk
from tkinter import ttk, scrolledtext
import requests, socket, ssl, whois, builtwith, dns.resolver, time
from bs4 import BeautifulSoup
from datetime import datetime

def analyze_website():
    url = url_entry.get().strip()
    if not url.startswith("http"):
        url = "http://" + url

    # Clear previous results
    for tab in tabs.values():
        tab.delete(1.0, tk.END)

    hostname = url.split("//")[-1].split("/")[0]

    try:
        # ---------- HTTP & Headers ----------
        start = time.time()
        response = requests.get(url, timeout=10)
        end = time.time()
        tabs['HTTP'].insert(tk.END, f"Status Code: {response.status_code}\n")
        tabs['HTTP'].insert(tk.END, f"Response Time: {round((end-start)*1000, 2)} ms\n")
        tabs['HTTP'].insert(tk.END, f"Redirect History: {response.history}\n\n")
        tabs['HTTP'].insert(tk.END, "Headers:\n")
        for k, v in response.headers.items():
            tabs['HTTP'].insert(tk.END, f"{k}: {v}\n")
        tabs['HTTP'].insert(tk.END, "\nCookies:\n")
        for k, v in response.cookies.items():
            tabs['HTTP'].insert(tk.END, f"{k}: {v}\n")

        # ---------- SSL Info ----------
        try:
            context = ssl.create_default_context()
            with socket.create_connection((hostname, 443), timeout=10) as sock:
                with context.wrap_socket(sock, server_hostname=hostname) as ssock:
                    cert = ssock.getpeercert()
            # Flatten nested tuples
            issuer = ", ".join(f"{t[0]}={t[1]}" for item in cert.get('issuer', []) for t in item)
            subject = ", ".join(f"{t[0]}={t[1]}" for item in cert.get('subject', []) for t in item)
            tabs['SSL'].insert(tk.END, f"Issuer: {issuer}\n")
            tabs['SSL'].insert(tk.END, f"Subject: {subject}\n")
            tabs['SSL'].insert(tk.END, f"Valid From: {cert.get('notBefore', 'N/A')}\n")
            tabs['SSL'].insert(tk.END, f"Valid To: {cert.get('notAfter', 'N/A')}\n")
            if 'notAfter' in cert:
                expire_date = datetime.strptime(cert['notAfter'], "%b %d %H:%M:%S %Y %Z")
                tabs['SSL'].insert(tk.END, f"Days Until Expiration: {(expire_date - datetime.utcnow()).days}\n")
        except Exception as e_ssl:
            tabs['SSL'].insert(tk.END, f"SSL Error: {e_ssl}\n")

        # ---------- Meta & DOM ----------
        soup = BeautifulSoup(response.text, 'html.parser')
        tabs['Meta'].insert(tk.END, f"Title: {soup.title.string if soup.title else 'N/A'}\n")
        for meta in soup.find_all("meta"):
            name = meta.get("name") or meta.get("property") or meta.get("http-equiv")
            content = meta.get("content")
            if name and content:
                tabs['Meta'].insert(tk.END, f"{name}: {content}\n")
        tabs['Meta'].insert(tk.END, f"\nScripts Count: {len(soup.find_all('script'))}\n")
        tabs['Meta'].insert(tk.END, f"Stylesheets Count: {len(soup.find_all('link', rel='stylesheet'))}\n")

        # ---------- Tech Stack ----------
        try:
            tech = builtwith.parse(url)
            tabs['Tech'].insert(tk.END, f"{tech}\n")
        except Exception as e_tech:
            tabs['Tech'].insert(tk.END, f"Tech Detection Error: {e_tech}\n")

        # ---------- WHOIS ----------
        try:
            domain_info = whois.whois(hostname)
            tabs['WHOIS'].insert(tk.END, f"{domain_info}\n")
        except Exception as e_whois:
            tabs['WHOIS'].insert(tk.END, f"WHOIS Error: {e_whois}\n")

        # ---------- DNS ----------
        for rtype in ['A','AAAA','MX','NS','TXT']:
            try:
                answers = dns.resolver.resolve(hostname, rtype)
                tabs['DNS'].insert(tk.END, f"{rtype} Records:\n")
                for r in answers:
                    tabs['DNS'].insert(tk.END, f"  {r.to_text()}\n")
            except Exception:
                tabs['DNS'].insert(tk.END, f"{rtype} Records: None or Unreachable\n")

    except Exception as e:
        for tab in tabs.values():
            tab.insert(tk.END, f"Error: {e}\n")

# GUI
root = tk.Tk()
root.title("Ultimate Web Inspector 2.0")

tk.Label(root, text="Enter Website URL:").pack()
url_entry = tk.Entry(root, width=50)
url_entry.pack()
tk.Button(root, text="Analyze", command=analyze_website).pack(pady=5)

notebook = ttk.Notebook(root)
notebook.pack(fill='both', expand=True)

tabs = {}
for tab_name in ['HTTP', 'SSL', 'Meta', 'Tech', 'WHOIS', 'DNS']:
    frame = ttk.Frame(notebook)
    notebook.add(frame, text=tab_name)
    text_area = scrolledtext.ScrolledText(frame, width=100, height=30)
    text_area.pack(fill='both', expand=True)
    tabs[tab_name] = text_area

root.mainloop()
