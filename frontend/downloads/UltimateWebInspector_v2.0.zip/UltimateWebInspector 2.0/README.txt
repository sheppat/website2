==========================================
           UsefulUtilities
       Ultimate Web Inspector
==========================================

Version: 2.0
Author: UsefulUtilities
Website: https://usefulutilities.shop
Contact: tylermicoson99@gmail.com
© 2025 UsefulUtilities. All rights reserved.

------------------------------------------
DESCRIPTION:
------------------------------------------
The Ultimate Web Inspector is a developer-focused utility that allows users to analyze websites in-depth. 
It provides multiple tabs of information including:

- HTTP status codes, headers, cookies, and redirect history
- SSL/TLS certificate details, issuer info, validity, and expiration countdown
- Meta tags, page title, structured data, scripts and stylesheet counts
- Detected technologies and frameworks via BuiltWith
- WHOIS and domain information
- DNS records: A, AAAA, MX, NS, TXT

This tool is designed for developers, researchers, security enthusiasts, and tech geeks who want a 
comprehensive look under the hood of any website.

------------------------------------------
SYSTEM REQUIREMENTS:
------------------------------------------
- Python 3.8 or higher
- Internet connection (required for online website analysis)
- Operating System: Windows, macOS, or Linux

------------------------------------------
DEPENDENCIES:
------------------------------------------
Install required Python libraries using pip:

pip install requests beautifulsoup4 builtwith python-whois dnspython pyOpenSSL

Note: Tkinter is included by default with most Python installations.

Explanation:
- `requests` → HTTP requests
- `beautifulsoup4` → Parsing HTML and extracting meta data
- `builtwith` → Detect technologies and frameworks
- `python-whois` → Domain WHOIS info
- `dnspython` → DNS record lookup
- `pyOpenSSL` → SSL certificate parsing
- Tkinter → GUI (comes with Python)

------------------------------------------
USAGE:
------------------------------------------
1. Run the utility by executing:

   python UltimateWebInspector.py

2. Enter the website URL you want to analyze.
3. Click the "Analyze" button.
4. View results in the multi-tab interface:

   - HTTP: Status, headers, cookies, redirects, and response time
   - SSL: Certificate details and expiration info
   - Meta: Meta tags, page title, scripts, and stylesheets
   - Tech: Detected frameworks, libraries, and technologies
   - WHOIS: Domain registration and ownership information
   - DNS: DNS records including A, AAAA, MX, NS, and TXT

------------------------------------------
CHANGELOG:
------------------------------------------
Version 2.0 - Released 2025

New Features:
- Added SSL tab with detailed certificate info, issuer, validity, and expiration countdown.
- Added DNS tab with A, AAAA, MX, NS, and TXT record enumeration.
- Enhanced HTTP tab: shows response time, redirect history, cookies, and headers.
- Enhanced Meta tab: added script and stylesheet counts, page title extraction.
- Improved Tech tab: BuiltWith detection remains, ready for future expansion with Wappalyzer.
- WHOIS tab now parses domains more reliably across different TLDs.
- Overall GUI improvements and multi-tab support for easier navigation.

Fixes/Improvements:
- Robust URL handling (auto adds http:// if missing)
- Better error handling across network, SSL, and DNS queries.
- Dependencies updated to ensure compatibility with Python 3.8+.
- Optimized performance for faster website analysis.

------------------------------------------
DISCLAIMER & TERMS OF USE:
------------------------------------------
All utilities on UsefulUtilities are 100% original and created solely by the owner of this website. 
They are crafted from scratch and hosted securely.

By downloading or using this utility, you agree to use it responsibly. UsefulUtilities is not liable for misuse 
or damage caused by improper use of the utility.

Redistribution, modification, or sale of this utility is strictly prohibited. 
You may share UsefulUtilities using its official website link only: https://usefulutilities.shop

ALL UTILITIES ARE PROVIDED AS-IS. While every effort is made to ensure safety and functionality, 
no guarantees are made regarding compatibility or performance.

***NO DISTRIBUTING OF THIS UTILITY IS ALLOWED.***

------------------------------------------
CONTACT:
------------------------------------------
For support or inquiries, contact: tylermicoson99@gmail.com

------------------------------------------
THANK YOU FOR USING USEFULUTILITIES
------------------------------------------
