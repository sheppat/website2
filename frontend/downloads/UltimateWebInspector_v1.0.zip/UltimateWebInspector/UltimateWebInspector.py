import tkinter as tk
from tkinter import ttk, scrolledtext
import requests
from bs4 import BeautifulSoup
import builtwith
import whois
import ssl, socket

def analyze_website():
    url = url_entry.get()
    if not url.startswith("http"):
        url = "http://" + url

    # Clear tabs
    for tab in tabs.values():
        tab.delete(1.0, tk.END)

    try:
        # ---- HTTP & Headers ----
        response = requests.get(url)
        tabs['HTTP'].insert(tk.END, f"Status Code: {response.status_code}\n")
        for k, v in response.headers.items():
            tabs['HTTP'].insert(tk.END, f"{k}: {v}\n")
        
        # ---- SSL Info ----
        hostname = url.split("//")[-1].split("/")[0]
        context = ssl.create_default_context()
        with socket.create_connection((hostname, 443)) as sock:
            with context.wrap_socket(sock, server_hostname=hostname) as ssock:
                cert = ssock.getpeercert()
        tabs['HTTP'].insert(tk.END, f"\nSSL Certificate:\n{cert}\n")

        # ---- Meta & DOM ----
        soup = BeautifulSoup(response.text, "html.parser")
        for meta in soup.find_all("meta"):
            name = meta.get("name") or meta.get("property") or meta.get("http-equiv")
            content = meta.get("content")
            if name and content:
                tabs['Meta'].insert(tk.END, f"{name}: {content}\n")

        # ---- Tech Stack ----
        tech = builtwith.parse(url)
        tabs['Tech'].insert(tk.END, f"{tech}\n")

        # ---- WHOIS ----
        domain_info = whois.whois(url)
        tabs['WHOIS'].insert(tk.END, f"{domain_info}\n")

    except Exception as e:
        for tab in tabs.values():
            tab.insert(tk.END, f"Error: {e}\n")

# GUI
root = tk.Tk()
root.title("Ultimate Web Inspector")

tk.Label(root, text="Enter Website URL:").pack()
url_entry = tk.Entry(root, width=50)
url_entry.pack()
tk.Button(root, text="Analyze", command=analyze_website).pack(pady=5)

notebook = ttk.Notebook(root)
notebook.pack(fill='both', expand=True)

tabs = {}
for tab_name in ['HTTP', 'Meta', 'Tech', 'WHOIS']:
    frame = ttk.Frame(notebook)
    notebook.add(frame, text=tab_name)
    text_area = scrolledtext.ScrolledText(frame, width=100, height=30)
    text_area.pack(fill='both', expand=True)
    tabs[tab_name] = text_area

root.mainloop()
